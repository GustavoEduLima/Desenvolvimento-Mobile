# 🍓 Gerenciador de Frutas — AC2 Mobile (Firebase)

Aplicativo Android para cadastrar e organizar frutas, usando **Firebase Firestore**
como banco de dados em nuvem (substitui o SQLite da AC1).

---

## 📁 Estrutura do Projeto

```
FrutasApp/
├── app/
│   ├── build.gradle                          ← dependências Firebase
│   └── src/main/
│       ├── AndroidManifest.xml               ← permissão INTERNET
│       ├── java/com/ac2/frutas/
│       │   ├── Fruta.java                    ← Modelo de dados
│       │   ├── FirebaseHelper.java           ← Camada de acesso ao Firestore (= DatabaseHelper do SQLite)
│       │   ├── FrutaAdapter.java             ← Adapter do RecyclerView
│       │   └── MainActivity.java            ← Tela principal (CRUD completo)
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml         ← Layout principal
│           │   └── item_fruta.xml            ← Item da lista
│           └── values/
│               ├── strings.xml
│               └── themes.xml
└── build.gradle                              ← plugin google-services
```

---

## 🚀 Como configurar o Firebase (OBRIGATÓRIO antes de rodar)

### Passo 1 — Criar projeto no Firebase Console
1. Acesse https://console.firebase.google.com
2. Clique em **"Adicionar projeto"**
3. Dê um nome (ex.: `FrutasAC2`) e clique em Continuar
4. Pode desativar o Google Analytics → **Criar projeto**

### Passo 2 — Adicionar app Android
1. Na tela do projeto, clique no ícone **Android**
2. Nome do pacote: `com.ac2.frutas`
3. Clique em **"Registrar app"**
4. Faça o download do arquivo `google-services.json`
5. **Coloque o arquivo em `app/google-services.json`** (dentro da pasta `app/`)

### Passo 3 — Ativar o Firestore
1. No console Firebase, vá em **Firestore Database**
2. Clique em **"Criar banco de dados"**
3. Escolha **"Iniciar no modo de teste"** (permite leitura/escrita sem autenticação)
4. Escolha a região (ex.: `southamerica-east1` para Brasil)
5. Clique em **"Ativar"**

### Passo 4 — Rodar o app
1. Abra a pasta `FrutasApp` no **Android Studio**
2. Aguarde o Gradle sincronizar
3. Execute em um emulador ou dispositivo físico

---

## ✅ Funcionalidades Implementadas

| Funcionalidade          | Detalhes |
|-------------------------|----------|
| **Cadastro**            | Nome, Origem, Safra, Categoria (Spinner), Descrição, Orgânica (CheckBox) |
| **Listagem**            | RecyclerView com todos os campos visíveis |
| **Edição**              | Clique curto → carrega dados no formulário → botão vira "Atualizar" |
| **Exclusão**            | Clique longo → AlertDialog de confirmação → exclui |
| **Filtro**              | Spinner filtra por categoria (Tropical, Cítrica, Vermelha, Outras, Todas) |
| **Validação**           | Nome, Origem e Safra não podem ficar vazios |
| **Persistência**        | Firebase Firestore — dados sobrevivem ao fechar/abrir o app |
| **Confirmação exclusão**| AlertDialog antes de excluir (extra opcional) |

---

## 🔄 SQLite → Firebase: Comparação para a apresentação

| Aspecto            | SQLite (AC1)                        | Firebase Firestore (AC2)               |
|--------------------|-------------------------------------|----------------------------------------|
| Onde fica o banco  | No dispositivo (local)              | Na nuvem (Google)                      |
| Operações          | Síncronas (resultado imediato)      | Assíncronas (callbacks/listeners)      |
| Estrutura          | Tabelas e colunas (SQL)             | Coleções e documentos (NoSQL/JSON)     |
| ID do registro     | `INTEGER PRIMARY KEY AUTOINCREMENT` | String gerada automaticamente          |
| Consulta com filtro| `WHERE categoria = ?`               | `.whereEqualTo("categoria", valor)`    |
| Resultado da query | `Cursor`                            | `QuerySnapshot` → `DocumentSnapshot`  |
| Offline            | Sempre funciona                     | Funciona (cache local automático)      |
| Compartilhamento   | Não (local)                         | Sim (múltiplos dispositivos/usuários)  |

---

## 💡 Pontos para destacar na apresentação

1. **FirebaseHelper.java** é o equivalente ao `DatabaseHelper.java` da AC1 — concentra todo acesso ao banco
2. O método `inserir()` usa `.add()` → Firestore gera o ID automaticamente
3. O método `atualizar()` usa `.update()` com o ID do documento salvo em `Fruta.id`
4. Todos os resultados são tratados em `.addOnSuccessListener()` e `.addOnFailureListener()` — nunca bloqueiam a UI
5. `doc.toObject(Fruta.class)` → desserialização automática (por isso o construtor vazio na classe `Fruta` é obrigatório!)

---

## ⚠️ Erro comum

**"Default FirebaseApp is not initialized"**
→ Você esqueceu de colocar o `google-services.json` em `app/` ou o plugin `com.google.gms.google-services` não está no `build.gradle`.
