package com.ac2.frutas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter para o RecyclerView que exibe a lista de frutas.
 * Cada item mostra: nome, origem, safra, categoria e status orgânica.
 */
public class FrutaAdapter extends RecyclerView.Adapter<FrutaAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Fruta fruta);         // Clique curto → editar
        void onItemLongClick(Fruta fruta);     // Clique longo → excluir
    }

    private final List<Fruta> lista;
    private final OnItemClickListener listener;

    public FrutaAdapter(List<Fruta> lista, OnItemClickListener listener) {
        this.lista = lista;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_fruta, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Fruta fruta = lista.get(position);

        holder.tvNome.setText(fruta.getNome());
        holder.tvOrigem.setText("Origem: " + fruta.getOrigem());
        holder.tvSafra.setText("Safra: " + fruta.getSafra());
        holder.tvCategoria.setText("Categoria: " + fruta.getCategoria());
        holder.tvOrganica.setText(fruta.isOrganica() ? "🌿 Orgânica" : "Convencional");

        holder.itemView.setOnClickListener(v -> listener.onItemClick(fruta));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onItemLongClick(fruta);
            return true;
        });
    }

    @Override
    public int getItemCount() { return lista.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNome, tvOrigem, tvSafra, tvCategoria, tvOrganica;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNome      = itemView.findViewById(R.id.tvNome);
            tvOrigem    = itemView.findViewById(R.id.tvOrigem);
            tvSafra     = itemView.findViewById(R.id.tvSafra);
            tvCategoria = itemView.findViewById(R.id.tvCategoria);
            tvOrganica  = itemView.findViewById(R.id.tvOrganica);
        }
    }
}
