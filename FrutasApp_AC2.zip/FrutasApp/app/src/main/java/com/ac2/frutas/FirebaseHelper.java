package com.ac2.frutas;

import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

/**
 * Camada de acesso ao Firebase Firestore.
 * Centraliza todas as operações de CRUD na coleção "frutas".
 *
 * Equivalente conceitual ao DatabaseHelper do SQLite — mas aqui
 * os dados vivem na nuvem e são sincronizados em tempo real.
 */
public class FirebaseHelper {

    // Nome da coleção no Firestore (equivale a uma tabela no SQLite)
    private static final String COLECAO = "frutas";

    private final CollectionReference colecaoRef;

    public FirebaseHelper() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        colecaoRef = db.collection(COLECAO);
    }

    /**
     * INSERT — Adiciona uma nova fruta.
     * O Firestore gera o ID do documento automaticamente.
     */
    public Task<com.google.firebase.firestore.DocumentReference> inserir(Fruta fruta) {
        Map<String, Object> dados = frutaParaMap(fruta);
        return colecaoRef.add(dados);
    }

    /**
     * UPDATE — Atualiza uma fruta existente pelo ID do documento.
     */
    public Task<Void> atualizar(Fruta fruta) {
        Map<String, Object> dados = frutaParaMap(fruta);
        return colecaoRef.document(fruta.getId()).update(dados);
    }

    /**
     * DELETE — Remove uma fruta pelo ID do documento.
     */
    public Task<Void> excluir(String id) {
        return colecaoRef.document(id).delete();
    }

    /**
     * SELECT ALL — Retorna todas as frutas ordenadas por nome.
     */
    public Task<QuerySnapshot> listarTodas() {
        return colecaoRef.orderBy("nome").get();
    }

    /**
     * SELECT com filtro por categoria (equivale a WHERE categoria = ?).
     */
    public Task<QuerySnapshot> listarPorCategoria(String categoria) {
        return colecaoRef
                .whereEqualTo("categoria", categoria)
                .orderBy("nome")
                .get();
    }

    /**
     * SELECT com filtro por orgânica.
     */
    public Task<QuerySnapshot> listarOrganicas() {
        return colecaoRef
                .whereEqualTo("organica", true)
                .orderBy("nome")
                .get();
    }

    // Converte o objeto Fruta para Map (necessário para o Firestore)
    private Map<String, Object> frutaParaMap(Fruta fruta) {
        Map<String, Object> dados = new HashMap<>();
        dados.put("nome",       fruta.getNome());
        dados.put("origem",     fruta.getOrigem());
        dados.put("safra",      fruta.getSafra());
        dados.put("categoria",  fruta.getCategoria());
        dados.put("descricao",  fruta.getDescricao());
        dados.put("organica",   fruta.isOrganica());
        return dados;
    }
}
