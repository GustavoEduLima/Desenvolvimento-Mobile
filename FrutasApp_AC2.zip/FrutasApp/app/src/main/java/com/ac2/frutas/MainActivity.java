package com.ac2.frutas;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

/**
 * Tela principal do app.
 *
 * Fluxo Firebase (comparação com SQLite):
 *  - SQLite:   db.insert(...)  → resultado imediato, síncrono
 *  - Firebase: colecao.add(…)  → retorna Task<>, resultado no listener (assíncrono)
 *
 * Por isso usamos .addOnSuccessListener() e .addOnFailureListener()
 * em todas as operações de escrita e leitura.
 */
public class MainActivity extends AppCompatActivity {

    // --- Componentes de UI ---
    private EditText etNome, etOrigem, etSafra, etDescricao;
    private Spinner  spinnerCategoria, spinnerFiltro;
    private CheckBox checkOrganica;
    private Button   btnSalvar, btnLimpar;
    private RecyclerView recyclerView;

    // --- Dados e Firebase ---
    private FirebaseHelper firebaseHelper;
    private FrutaAdapter   adapter;
    private List<Fruta>    listaFrutas;

    // Controle de edição: null = modo inserção, !null = modo edição
    private Fruta frutaEmEdicao = null;

    // Categorias disponíveis
    private static final String[] CATEGORIAS =
            {"Todas", "Tropical", "Cítrica", "Vermelha", "Outras"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseHelper = new FirebaseHelper();
        listaFrutas    = new ArrayList<>();

        inicializarViews();
        configurarSpinners();
        configurarRecyclerView();
        carregarFrutas("Todas"); // Carrega todas ao abrir
    }

    // -------------------------------------------------------------------------
    // Inicialização de views
    // -------------------------------------------------------------------------

    private void inicializarViews() {
        etNome          = findViewById(R.id.etNome);
        etOrigem        = findViewById(R.id.etOrigem);
        etSafra         = findViewById(R.id.etSafra);
        etDescricao     = findViewById(R.id.etDescricao);
        spinnerCategoria= findViewById(R.id.spinnerCategoria);
        spinnerFiltro   = findViewById(R.id.spinnerFiltro);
        checkOrganica   = findViewById(R.id.checkOrganica);
        btnSalvar       = findViewById(R.id.btnSalvar);
        btnLimpar       = findViewById(R.id.btnLimpar);
        recyclerView    = findViewById(R.id.recyclerView);

        btnSalvar.setOnClickListener(v -> salvarOuAtualizar());
        btnLimpar.setOnClickListener(v -> limparCampos());
    }

    private void configurarSpinners() {
        // Spinner de categoria (no cadastro)
        String[] categoriasForm = {"Tropical", "Cítrica", "Vermelha", "Outras"};
        ArrayAdapter<String> adapterCat = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, categoriasForm);
        adapterCat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoria.setAdapter(adapterCat);

        // Spinner de filtro (na listagem)
        ArrayAdapter<String> adapterFiltro = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, CATEGORIAS);
        adapterFiltro.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFiltro.setAdapter(adapterFiltro);

        spinnerFiltro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                carregarFrutas(CATEGORIAS[pos]);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void configurarRecyclerView() {
        adapter = new FrutaAdapter(listaFrutas, new FrutaAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Fruta fruta) {
                // Clique curto → carrega dados para edição
                carregarParaEdicao(fruta);
            }
            @Override
            public void onItemLongClick(Fruta fruta) {
                // Clique longo → confirmar exclusão
                confirmarExclusao(fruta);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    // -------------------------------------------------------------------------
    // CRUD — Operações Firebase
    // -------------------------------------------------------------------------

    /**
     * Decide entre INSERT e UPDATE conforme frutaEmEdicao.
     */
    private void salvarOuAtualizar() {
        if (!validarCampos()) return;

        Fruta fruta = coletarDadosDoFormulario();

        if (frutaEmEdicao == null) {
            // --- INSERT ---
            firebaseHelper.inserir(fruta)
                .addOnSuccessListener(docRef -> {
                    Toast.makeText(this, "Fruta cadastrada!", Toast.LENGTH_SHORT).show();
                    limparCampos();
                    carregarFrutas(CATEGORIAS[spinnerFiltro.getSelectedItemPosition()]);
                })
                .addOnFailureListener(e ->
                    Toast.makeText(this, "Erro ao salvar: " + e.getMessage(),
                            Toast.LENGTH_LONG).show());
        } else {
            // --- UPDATE ---
            fruta.setId(frutaEmEdicao.getId()); // mantém o mesmo ID de documento
            firebaseHelper.atualizar(fruta)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Fruta atualizada!", Toast.LENGTH_SHORT).show();
                    frutaEmEdicao = null;
                    btnSalvar.setText("Salvar");
                    limparCampos();
                    carregarFrutas(CATEGORIAS[spinnerFiltro.getSelectedItemPosition()]);
                })
                .addOnFailureListener(e ->
                    Toast.makeText(this, "Erro ao atualizar: " + e.getMessage(),
                            Toast.LENGTH_LONG).show());
        }
    }

    /**
     * Carrega a lista do Firestore — com ou sem filtro de categoria.
     * Equivalente a um SELECT no SQLite.
     */
    private void carregarFrutas(String categoriaFiltro) {
        // Escolhe a query certa com base no filtro selecionado
        var task = categoriaFiltro.equals("Todas")
                ? firebaseHelper.listarTodas()
                : firebaseHelper.listarPorCategoria(categoriaFiltro);

        task.addOnSuccessListener((QuerySnapshot snapshot) -> {
                listaFrutas.clear();
                for (DocumentSnapshot doc : snapshot.getDocuments()) {
                    Fruta f = doc.toObject(Fruta.class); // desserialização automática
                    if (f != null) {
                        f.setId(doc.getId()); // salva o ID do documento no objeto
                        listaFrutas.add(f);
                    }
                }
                adapter.notifyDataSetChanged();
            })
            .addOnFailureListener(e ->
                Toast.makeText(this, "Erro ao carregar: " + e.getMessage(),
                        Toast.LENGTH_LONG).show());
    }

    /**
     * Exibe AlertDialog de confirmação antes de excluir.
     */
    private void confirmarExclusao(Fruta fruta) {
        new AlertDialog.Builder(this)
            .setTitle("Excluir Fruta")
            .setMessage("Deseja excluir \"" + fruta.getNome() + "\"?")
            .setPositiveButton("Excluir", (dialog, which) -> excluir(fruta))
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void excluir(Fruta fruta) {
        firebaseHelper.excluir(fruta.getId())
            .addOnSuccessListener(unused -> {
                Toast.makeText(this, "Fruta excluída!", Toast.LENGTH_SHORT).show();
                carregarFrutas(CATEGORIAS[spinnerFiltro.getSelectedItemPosition()]);
            })
            .addOnFailureListener(e ->
                Toast.makeText(this, "Erro ao excluir: " + e.getMessage(),
                        Toast.LENGTH_LONG).show());
    }

    // -------------------------------------------------------------------------
    // Helpers de UI
    // -------------------------------------------------------------------------

    /** Preenche os campos com os dados da fruta selecionada para edição. */
    private void carregarParaEdicao(Fruta fruta) {
        frutaEmEdicao = fruta;
        etNome.setText(fruta.getNome());
        etOrigem.setText(fruta.getOrigem());
        etSafra.setText(fruta.getSafra());
        etDescricao.setText(fruta.getDescricao());
        checkOrganica.setChecked(fruta.isOrganica());

        // Seleciona a categoria correta no Spinner
        String[] categorias = {"Tropical", "Cítrica", "Vermelha", "Outras"};
        for (int i = 0; i < categorias.length; i++) {
            if (categorias[i].equals(fruta.getCategoria())) {
                spinnerCategoria.setSelection(i);
                break;
            }
        }

        btnSalvar.setText("Atualizar"); // Muda texto do botão para indicar modo edição
        Toast.makeText(this, "Editando: " + fruta.getNome(), Toast.LENGTH_SHORT).show();
    }

    /** Coleta os dados do formulário e retorna um objeto Fruta. */
    private Fruta coletarDadosDoFormulario() {
        return new Fruta(
            etNome.getText().toString().trim(),
            etOrigem.getText().toString().trim(),
            etSafra.getText().toString().trim(),
            spinnerCategoria.getSelectedItem().toString(),
            etDescricao.getText().toString().trim(),
            checkOrganica.isChecked()
        );
    }

    /**
     * Validações obrigatórias — campos não podem estar vazios.
     * Retorna true se tudo OK, false caso contrário.
     */
    private boolean validarCampos() {
        if (etNome.getText().toString().trim().isEmpty()) {
            etNome.setError("Nome é obrigatório");
            etNome.requestFocus();
            return false;
        }
        if (etOrigem.getText().toString().trim().isEmpty()) {
            etOrigem.setError("Origem é obrigatória");
            etOrigem.requestFocus();
            return false;
        }
        if (etSafra.getText().toString().trim().isEmpty()) {
            etSafra.setError("Safra é obrigatória");
            etSafra.requestFocus();
            return false;
        }
        return true;
    }

    private void limparCampos() {
        etNome.setText("");
        etOrigem.setText("");
        etSafra.setText("");
        etDescricao.setText("");
        checkOrganica.setChecked(false);
        spinnerCategoria.setSelection(0);
        frutaEmEdicao = null;
        btnSalvar.setText("Salvar");
    }
}
