package com.ac2.frutas;

/**
 * Modelo de dados para uma Fruta.
 * O campo 'id' armazena o ID do documento no Firestore.
 */
public class Fruta {

    private String id;         // ID do documento no Firestore
    private String nome;       // ex.: "Manga", "Morango"
    private String origem;     // ex.: "Brasil", "Chile"
    private String safra;      // Data/período de safra (ex.: "Jan/Fev")
    private String categoria;  // Spinner: Tropical, Cítrica, Vermelha, Outras
    private String descricao;  // Descrição livre
    private boolean organica;  // CheckBox: é orgânica?

    // Construtor vazio OBRIGATÓRIO para o Firestore desserializar automaticamente
    public Fruta() {}

    public Fruta(String nome, String origem, String safra,
                 String categoria, String descricao, boolean organica) {
        this.nome = nome;
        this.origem = origem;
        this.safra = safra;
        this.categoria = categoria;
        this.descricao = descricao;
        this.organica = organica;
    }

    // --- Getters e Setters ---

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getOrigem() { return origem; }
    public void setOrigem(String origem) { this.origem = origem; }

    public String getSafra() { return safra; }
    public void setSafra(String safra) { this.safra = safra; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public boolean isOrganica() { return organica; }
    public void setOrganica(boolean organica) { this.organica = organica; }
}
